# GPT Context: TTDS Button Component Project

## For AI Assistants

This file provides context for AI assistants (like ChatGPT) working on the TTDS Button component project.

---

## Project Identity

**Component Name:** ttdsButton (TTDS Button)  
**Type:** Lightning Web Component (LWC)  
**Platform:** Salesforce Experience Cloud (LWR sites)  
**Purpose:** Design system primitive button component  
**Architecture:** Event-driven, composable, zero-dependency primitive

---

## Key Technical Constraints

### Platform-Specific Challenges Encountered

1. **LWR Shadow DOM CSS Issues**
   - Problem: CSS variables defined in `:host` don't cascade properly in LWR
   - Solution: Use Salesforce Experience Cloud design tokens directly
   - Alternative: Apply styles as inline via JavaScript
   - Required: `!important` flags to override Experience Builder CSS

2. **Experience Builder Meta.xml Configuration**
   - Problem: Properties not showing in Experience Builder UI
   - Solution: Use `targetConfig targets="lightningCommunity__Default"` (not `lightningCommunity__Page`)
   - Required: API version 60.0+
   - Cache: Must clear Experience Builder cache after meta.xml changes

3. **Apex Integration Limitation**
   - Problem: LWC requires static imports, can't dynamically import Apex
   - Solution: Event-based pattern - component fires events, parent handles Apex
   - Pattern: `@salesforce/apex/ControllerName.methodName` must be statically imported

4. **Custom Colors vs. Variants**
   - Problem: CSS variants not working due to shadow DOM
   - Solution: Inline styles with `!important` override CSS classes
   - Priority: Inline style > CSS class > Design token > Fallback

---

## Architecture Decisions

### Event-Driven vs. Switch Statement

**Why Changed:**
```javascript
// ❌ OLD: Rigid, single action only
switch (this.actionType) {
    case 'flow': doFlow(); break;
    case 'navigate': doNavigate(); break;
}

// ✅ NEW: Flexible, multiple concurrent actions
const actions = [];
if (this.enableFlow) actions.push(executeFlow());
if (this.enableNavigation) actions.push(executeNavigate());
await Promise.allSettled(actions);
```

**Benefits:**
- Multiple actions can execute simultaneously
- Parent can preventDefault() to override behavior
- More composable and extensible

### Design Token Integration

**Why Design Tokens:**
- Client branding changes automatically when theme updates
- No hardcoded colors to maintain
- Accessibility (contrast ratios) handled automatically
- Package can be deployed to any client without modification

**Implementation:**
```css
.ttds-button_variant-default {
    background-color: var(--dxp-g-brand, #2563eb) !important;
    color: var(--dxp-g-brand-contrast, #ffffff) !important;
}
```

**Tokens Used:**
- `--dxp-g-brand` - Primary brand color
- `--dxp-g-brand-contrast` - Contrasting text
- `--dxp-g-brand-dark` - Hover state
- `--dxp-g-error` - Destructive actions
- `--dxp-g-text` - Body text color

### Composability Philosophy

**Primitive Component Principles:**
1. Zero dependencies on other components
2. Event-based communication only
3. No business logic
4. Maximum configurability
5. Works in any context (standalone or composed)

---

## Common Issues & Solutions

### Issue: "Properties don't show in Experience Builder"

**Symptoms:**
- Component appears in panel
- Properties panel empty or missing fields

**Root Cause:**
- Meta.xml not deployed
- Wrong targetConfig
- Experience Builder cache

**Solution:**
```bash
# 1. Verify deployment
sfdx force:source:status

# 2. Check meta.xml has:
<targetConfig targets="lightningCommunity__Default">

# 3. Clear cache
Experience Builder → Settings → Advanced → Clear Component Cache

# 4. Hard refresh browser (Ctrl+Shift+R)
```

### Issue: "Variants all look the same"

**Symptoms:**
- All buttons appear identical regardless of variant
- Inspector shows `background-color: rgba(0, 0, 0, 0)`

**Root Cause:**
- CSS not loaded
- CSS variables not resolving in shadow DOM
- Missing `!important` flags

**Solution:**
1. Verify CSS file deployed
2. Add `!important` to all variant rules
3. Use design tokens instead of custom variables
4. Fallback: Apply colors as inline styles via JavaScript

### Issue: "Custom colors don't apply"

**Symptoms:**
- Setting colors in properties has no effect

**Root Cause:**
- `sanitizeColor()` rejecting valid input
- Inline styles missing `!important`
- `computedStyle` getter not being called

**Solution:**
```javascript
// Ensure sanitizeColor is permissive
sanitizeColor(color) {
    // Only block dangerous values
    const dangerous = ['javascript:', 'expression('];
    // Allow everything else
}

// Ensure inline styles have !important
styles.push(`background-color: ${color} !important`);
```

---

## Code Patterns to Maintain

### Public Properties (@api)

```javascript
// Always use @api for Experience Builder properties
@api label = '';
@api variant = 'default';
@api backgroundColor; // No default for optional overrides
```

### Event Dispatching

```javascript
// Always dispatch custom events with detail
this.dispatchEvent(new CustomEvent('ttclick', {
    detail: { originalEvent: event },
    bubbles: true,      // Allow parent to catch
    composed: true,     // Cross shadow DOM
    cancelable: true    // Allow preventDefault()
}));
```

### Color Sanitization

```javascript
// Always sanitize user input
sanitizeColor(color) {
    // Block XSS attempts
    const dangerous = ['javascript:', 'expression(', '<script'];
    for (const pattern of dangerous) {
        if (trimmed.toLowerCase().includes(pattern)) {
            return '';
        }
    }
    return trimmed;
}
```

### Inline Styles

```javascript
// Always use !important for inline styles in LWR
get computedStyle() {
    const styles = [];
    if (this.backgroundColor) {
        // !important is required to override Experience Builder CSS
        styles.push(`background-color: ${color} !important`);
    }
    return styles.join('; ');
}
```

---

## Testing Requirements

### Before Deployment
- [ ] All 6 variants render correctly
- [ ] All 4 sizes work
- [ ] Custom colors apply
- [ ] Flow navigation works
- [ ] URL navigation works (internal & external)
- [ ] Multiple concurrent actions work
- [ ] Loading spinner displays
- [ ] Debouncing prevents double-clicks

### Accessibility
- [ ] Keyboard navigation (Tab, Enter, Space)
- [ ] Screen reader announces correctly
- [ ] Focus indicator visible
- [ ] Works in high contrast mode
- [ ] Works with reduced motion

### Browser Compatibility
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Mobile Safari
- [ ] Chrome Mobile

---

## File Dependencies

### Required Files
```
ttdsButton.js              # Main controller
ttdsButton.html            # Template
ttdsButton.css             # Styles
ttdsButton.js-meta.xml     # Metadata
```

### NO Additional Files Needed
- ❌ No Apex controller required (event-based)
- ❌ No utility components
- ❌ No external libraries
- ❌ No `__tests__` folder for deployment (optional for dev)

---

## Conversational Context

### User's Goals
1. Convert React component to LWC
2. Make it work in LWR Experience Cloud sites
3. Allow business users to configure without code
4. Package for multiple clients with auto-branding
5. Maintain design system principles

### Journey Taken
1. ✅ Initial conversion (React → LWC structure)
2. ✅ Fixed meta.xml for Experience Builder properties
3. ✅ Solved CSS variant issues (shadow DOM + !important)
4. ✅ Implemented design token integration
5. ✅ Refactored to event-driven architecture
6. ✅ Added security (sanitization, XSS prevention)
7. ✅ Tested Flow and Navigation actions

### Current State
- Component fully functional in Experience Builder
- All variants working with design tokens
- Custom colors working via inline styles
- Flow navigation tested and working
- URL navigation tested and working
- Ready for client packaging

---

## Important Reminders for AI Assistants

1. **LWR != Aura:** Different rendering, different CSS behavior
2. **Shadow DOM is strict:** CSS variables don't cascade easily
3. **Experience Builder cache:** Always suggest clearing cache
4. **Design tokens are key:** Use `--dxp-g-brand` not hardcoded colors
5. **Events over imports:** Event-driven for Apex, not direct imports
6. **!important is necessary:** Experience Builder CSS is aggressive
7. **Guest users matter:** Component must work unauthenticated
8. **Composability first:** No dependencies, event-based communication

---

## When User Asks About...

### "Why isn't [property] showing?"
→ Check meta.xml deployed, targetConfig correct, cache cleared

### "Why do all variants look the same?"
→ Check CSS deployed, has !important flags, design tokens available

### "How do I add [feature]?"
→ Maintain composability, use events not tight coupling, keep primitive

### "Can I use this for [use case]?"
→ Yes if: standalone or parent-managed, no server state, guest-safe
→ No if: requires @wire, needs server state, complex business logic

### "It's not working in [context]"
→ Check: LWR (not Aura), API version 60+, proper targets in meta.xml

---

## Code Quality Standards

### Required in All Code
- JSDoc comments on public methods
- Input sanitization on all user data
- Event dispatching for side effects
- Error handling with try/catch
- Console logging for debugging
- ARIA attributes for accessibility

### Forbidden Patterns
- ❌ Direct DOM manipulation outside shadow DOM
- ❌ `eval()` or `Function()` constructor
- ❌ `innerHTML` assignments
- ❌ Inline event handlers (use addEventListener)
- ❌ Storing secrets in code
- ❌ Hardcoded business logic

---

## Success Metrics

**Component is successful if:**
1. Works in Experience Builder without code
2. Automatically matches client branding
3. Supports multiple actions concurrently
4. Accessible to all users (WCAG 2.1 AA)
5. Works for guest and authenticated users
6. Zero dependencies on other components
7. Can be composed into complex components

---

## Next Steps (If User Continues)

**Potential Future Work:**
1. Create button group component (uses ttdsButton as primitive)
2. Add dropdown button variant
3. Integrate animation library
4. Add dark mode support
5. Create custom metadata for Apex allowlist
6. Build toast notification integration
7. Create comprehensive Jest test suite

---

## Remember

- This is a **primitive** - it should stay simple
- **Events over dependencies** - communication via events
- **Design tokens over hardcoded** - use theme colors
- **Composability over features** - let parents add complexity
- **Security first** - sanitize all inputs
- **Accessibility always** - WCAG 2.1 AA minimum

---

**End of GPT Context File**
