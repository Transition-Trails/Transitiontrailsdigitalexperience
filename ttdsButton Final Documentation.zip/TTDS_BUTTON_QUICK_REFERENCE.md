# TTDS Button - Quick Reference Card

## Component Files
```
ttdsButton/
├── ttdsButton.js              # Controller (event-driven logic)
├── ttdsButton.html            # Template (button + spinner)
├── ttdsButton.css             # Styles (design tokens)
└── ttdsButton.js-meta.xml     # Config (Experience Builder)
```

## Deploy
```bash
sfdx force:source:deploy -p force-app/main/default/lwc/ttdsButton
```

## Variants
| Variant | Color | Use |
|---------|-------|-----|
| `default` | Brand | Primary CTA |
| `destructive` | Red | Delete/Danger |
| `outline` | Border | Secondary |
| `secondary` | Gray | Tertiary |
| `ghost` | Transparent | Subtle |
| `link` | Brand text | Text link |

## Sizes
- `default` - 36px
- `sm` - 32px
- `lg` - 40px
- `icon` - Square

## Actions (Multiple Concurrent)
- ✓ Flow Navigation
- ✓ URL Navigation (_self / _blank)
- ✓ Apex Calls (event-based)
- ✓ Custom Events

## Events
```javascript
ttclick      // Always fires first
ttsuccess    // All actions succeed
tterror      // Any action fails
ttflowlaunch // Flow triggered
ttnavigation // Navigation triggered
ttapexcall   // Apex triggered
```

## Usage Examples

### Basic Button
```html
<c-ttds-button label="Click Me" variant="default"></c-ttds-button>
```

### With Flow
```html
<c-ttds-button
    label="Start Process"
    enable-flow={true}
    flow-api-name="My_Flow"
    show-loading-spinner={true}
></c-ttds-button>
```

### With Navigation
```html
<c-ttds-button
    label="Learn More"
    enable-navigation={true}
    navigation-url="/about"
></c-ttds-button>
```

### Multiple Actions
```html
<c-ttds-button
    label="Submit"
    enable-flow={true}
    flow-api-name="Submit_Form"
    enable-navigation={true}
    navigation-url="/thank-you"
></c-ttds-button>
```

### Custom Colors
```html
<c-ttds-button
    label="Special"
    background-color="#7c3aed"
    text-color="#ffffff"
></c-ttds-button>
```

### With Events
```html
<c-ttds-button
    label="Custom"
    onttclick={handleClick}
    onttsuccess={handleSuccess}
></c-ttds-button>
```

```javascript
handleClick(event) {
    event.preventDefault(); // Stop actions
}

handleSuccess(event) {
    console.log('Done!', event.detail.results);
}
```

## Design Tokens
```css
--dxp-g-brand           /* Brand color */
--dxp-g-brand-contrast  /* Contrasting text */
--dxp-g-brand-dark      /* Hover state */
--dxp-g-error           /* Error color */
--dxp-g-text            /* Body text */
```

## Troubleshooting

### Properties Don't Show
1. Check meta.xml deployed
2. Clear Experience Builder cache
3. Verify targetConfig = "lightningCommunity__Default"
4. Hard refresh (Ctrl+Shift+R)

### Variants Don't Work
1. Verify CSS deployed
2. Add `!important` to CSS rules
3. Use design tokens
4. Check browser inspector

### Colors Don't Apply
1. Check `sanitizeColor()` function
2. Ensure inline styles have `!important`
3. Look for console warnings
4. Inspect computed styles

### Actions Don't Fire
1. Verify `enable[Action]` is true
2. Check required properties set
3. Look for console errors
4. Test events with logging

## Best Practices

✅ **DO:**
- Use semantic variants
- Provide aria-label for icons
- Enable spinner for async
- Test keyboard navigation
- Use design tokens

❌ **DON'T:**
- Nest buttons
- Use without text
- Disable without reason
- Hardcode colors
- Skip accessibility

## Security Checklist
- ✓ URL sanitization (blocks javascript:)
- ✓ Color validation (blocks XSS)
- ✓ Input sanitization on all @api
- ✓ CSP compliant
- ✓ Guest user safe

## Accessibility Checklist
- ✓ Keyboard navigation (Tab, Enter, Space)
- ✓ Screen reader support (ARIA)
- ✓ Focus indicators
- ✓ High contrast mode
- ✓ Reduced motion
- ✓ Color contrast (WCAG 2.1 AA)

## Browser Support
- Chrome/Edge ✓
- Firefox ✓
- Safari ✓
- Mobile Safari ✓
- Chrome Mobile ✓

## Performance
- Bundle: ~30KB (8KB gzipped)
- Render: <50ms
- Click: <100ms
- Debounce: 300ms

## Version
- Current: 2.0 (Event-Driven)
- API: 60.0+
- Platform: LWR Experience Cloud

## Quick Commands
```bash
# Deploy
sfdx force:source:deploy -p force-app/main/default/lwc/ttdsButton

# Check status
sfdx force:source:status

# Retrieve
sfdx force:source:retrieve -m LightningComponentBundle:ttdsButton

# Delete
sfdx force:source:delete -p force-app/main/default/lwc/ttdsButton
```

## Links
- Full Docs: TTDS_BUTTON_DOCUMENTATION.md
- GPT Context: TTDS_BUTTON_GPT_CONTEXT.md
- Examples: See documentation
- Support: Development team

---

**Remember:** This is a primitive. Keep it simple, composable, and dependency-free.
