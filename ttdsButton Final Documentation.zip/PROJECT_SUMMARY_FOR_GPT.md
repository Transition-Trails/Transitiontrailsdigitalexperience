# TTDS Button Component - Project Summary for GPT

## What to Upload to Your Custom GPT

Upload these 3 files to your GPT's knowledge base:

1. **TTDS_BUTTON_DOCUMENTATION.md** (22KB) - Complete technical documentation
2. **TTDS_BUTTON_GPT_CONTEXT.md** (11KB) - AI-specific context and common issues
3. **TTDS_BUTTON_QUICK_REFERENCE.md** (4.6KB) - Quick lookup reference

---

## What This GPT Should Know

### Core Identity
This is a **Lightning Web Component (LWC)** called `ttdsButton` that serves as a design system primitive for Salesforce Experience Cloud LWR sites. It's event-driven, composable, and uses design tokens for automatic client branding.

### Key Technical Facts

**Platform:** Salesforce Experience Cloud (LWR sites only)  
**Architecture:** Event-driven, zero dependencies  
**Size:** 4 files totaling ~30KB  
**Actions:** Flow, Navigation, Apex (event-based)  
**Styling:** Design tokens + custom colors  
**Users:** Guest and authenticated  

### Critical Issues Solved During Development

1. **CSS Variables in LWR Shadow DOM**
   - Problem: Variables don't cascade
   - Solution: Use Experience Cloud design tokens (`--dxp-g-brand`)
   - Requires: `!important` flags on all rules

2. **Experience Builder Property Configuration**
   - Problem: Properties not showing in UI
   - Solution: Use `targetConfig targets="lightningCommunity__Default"`
   - Required: Clear cache after meta.xml changes

3. **Event-Driven vs. Switch Statement**
   - Problem: Original used rigid switch for single action
   - Solution: Flag-based system with `Promise.allSettled()`
   - Benefit: Multiple concurrent actions

4. **Design Token Integration**
   - Problem: Buttons need to match client branding automatically
   - Solution: Use `--dxp-g-brand` CSS variable
   - Result: Automatic brand color inheritance

### When User Asks...

**"How do I [add/change/fix] something?"**
→ Refer to TTDS_BUTTON_DOCUMENTATION.md sections

**"Why isn't it working?"**
→ Check TTDS_BUTTON_GPT_CONTEXT.md "Common Issues & Solutions"

**"How do I deploy/configure?"**
→ Use TTDS_BUTTON_QUICK_REFERENCE.md

**"Can I use it for [X]?"**
→ Check if: standalone, event-based, guest-safe, no server state

### Important Constraints

**Must Maintain:**
- Zero dependencies (true primitive)
- Event-based communication
- Guest user compatibility
- Design token usage
- Composability

**Cannot Do:**
- Dynamic Apex imports (LWC limitation)
- Store server state (@wire not allowed)
- Complex business logic (primitive)
- Dependency on other components

### Code Patterns to Preserve

```javascript
// Always use @api for properties
@api label = '';

// Always sanitize input
sanitizeColor(color) { /* ... */ }

// Always use events
this.dispatchEvent(new CustomEvent('ttclick', {
    detail: {...},
    bubbles: true,
    composed: true
}));

// Always use !important for inline styles
styles.push(`background-color: ${color} !important`);
```

### Testing Requirements

Before any modification:
- [ ] All 6 variants still work
- [ ] Design tokens still pull brand color
- [ ] Custom colors still override
- [ ] Actions (Flow/Nav/Apex) still work
- [ ] Events still fire correctly
- [ ] Accessibility still compliant

---

## Conversation History Context

### What We Built
Started with a React button component and converted it to a production-ready LWC for Salesforce Experience Cloud. Encountered and solved multiple platform-specific issues including CSS shadow DOM, Experience Builder configuration, and event-driven architecture implementation.

### Journey Phases
1. Initial React to LWC conversion
2. Fixing Experience Builder property visibility
3. Solving CSS variant issues in LWR
4. Implementing design token integration
5. Refactoring to event-driven architecture
6. Adding security and accessibility
7. Testing and documentation

### Final State
- Fully functional in Experience Builder ✓
- All variants working with design tokens ✓
- Multiple concurrent actions supported ✓
- Flow and Navigation tested and working ✓
- Ready for client packaging ✓

---

## Instructions for GPT Usage

### When User References This Project

**Do:**
- Reference specific sections from documentation
- Cite file names and line numbers when relevant
- Explain trade-offs and decisions made
- Suggest testing after changes
- Maintain composability principles

**Don't:**
- Suggest breaking changes without explanation
- Add dependencies without strong justification
- Remove security features
- Hardcode values (use design tokens)
- Bypass event-driven patterns

### When User Asks for Modifications

**Always:**
1. Explain impact on composability
2. Check if it maintains primitive philosophy
3. Ensure guest user compatibility
4. Verify design token usage
5. Suggest testing checklist

**Never:**
- Add `@wire` adapters (makes stateful)
- Create component dependencies
- Hardcode business logic
- Skip input sanitization
- Ignore accessibility

### When User Reports Issues

**Debugging Order:**
1. Check documentation for known issues
2. Verify deployment (meta.xml, CSS, JS)
3. Clear Experience Builder cache
4. Check browser console
5. Inspect element in DevTools
6. Review GPT context for similar issues

---

## Success Criteria

**Component is working correctly if:**
1. ✓ Shows in Experience Builder component panel
2. ✓ All properties appear in properties panel
3. ✓ Variants change appearance visually
4. ✓ Custom colors override variants
5. ✓ Actions execute as configured
6. ✓ Events fire and can be caught
7. ✓ Works for guest users
8. ✓ Accessible via keyboard

---

## Common User Questions (Prepare Responses)

**Q: "Can I add [feature]?"**
A: Check if: maintains primitive philosophy, event-driven, guest-safe, no dependencies

**Q: "Why use events instead of direct calls?"**
A: Composability, parent control, LWC limitations, guest compatibility

**Q: "Can this work in Aura?"**
A: No, designed for LWR. Different rendering, different constraints.

**Q: "How do I change the default colors?"**
A: Don't hardcode. Use design tokens or custom color properties.

**Q: "Can I call Apex directly?"**
A: No, use event pattern. Parent component imports and calls Apex.

---

## Files Included in Package

**Core Component:**
- ttdsButton.js (17KB) - Controller
- ttdsButton.html (1.3KB) - Template
- ttdsButton.css (11KB) - Styles
- ttdsButton.js-meta.xml (8.4KB) - Metadata

**Documentation:**
- TTDS_BUTTON_DOCUMENTATION.md (22KB) - Full docs
- TTDS_BUTTON_GPT_CONTEXT.md (11KB) - GPT context
- TTDS_BUTTON_QUICK_REFERENCE.md (4.6KB) - Quick ref
- EXECUTIVE_SUMMARY.md (9.3KB) - Overview
- ARCHITECTURE.md (19KB) - Technical details
- DEPLOYMENT_CHECKLIST.md (9.6KB) - QA checklist
- README.md (12KB) - Standard readme
- EXAMPLES.js (17KB) - Code examples

**Optional:**
- ttdsButton.test.js (18KB) - Jest tests

---

## Version Information

**Current:** v2.0.0 (Event-Driven)  
**API Version:** 60.0+  
**Salesforce:** Experience Cloud LWR  
**Status:** Production Ready  
**Last Updated:** 2024-11-29  

---

## Contact & Support

For questions about this project:
1. Consult documentation files
2. Review GPT context for solutions
3. Check quick reference for syntax
4. Test in isolation
5. Contact development team

---

## License

Proprietary - Transition Trails Design System

---

**This summary provides everything needed for a GPT to effectively assist with the TTDS Button component project.**
